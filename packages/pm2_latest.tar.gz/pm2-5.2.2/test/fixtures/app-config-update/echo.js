
var i = 0;
setInterval(function() {
  console.log('ok', i++);
}, 2000);

console.log('ok');
