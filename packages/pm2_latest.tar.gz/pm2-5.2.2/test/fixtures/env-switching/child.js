
setInterval(function() {
  console.log(process.env.NODE_ENV);
}, 1000);
