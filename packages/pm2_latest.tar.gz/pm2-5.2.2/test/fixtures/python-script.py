import time

if __name__ == "__main__":
    while 1:
        print 'Script.py: alive'
        time.sleep(1)
