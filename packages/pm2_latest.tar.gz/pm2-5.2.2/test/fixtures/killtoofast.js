
setInterval(function() {
  console.log('BOUM');
  process.exit(1);
}, 30);
