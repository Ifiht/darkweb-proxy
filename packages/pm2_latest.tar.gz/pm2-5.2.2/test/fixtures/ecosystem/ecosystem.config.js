
module.exports = {
  script: 'unknown.js'
}
