while true; do
    ls -l
    sleep 5
done

