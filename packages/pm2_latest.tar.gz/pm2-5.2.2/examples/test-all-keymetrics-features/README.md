
Try all features of Keymetrics:

```bash
# Make sure you've created keymetrics account
$ pm2 register
# Start all applications
$ pm2 start process.config.js
# Open Dashboard
$ pm2 open
```
