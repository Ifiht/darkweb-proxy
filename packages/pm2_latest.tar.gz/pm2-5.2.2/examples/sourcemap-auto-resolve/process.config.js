module.exports = {
  apps : [{
    name   : "API-minified",
    script : "API.min.js"
  }]
}
