
function crash() {
  throw 'crashed';
}

crash();
