

var a =require('./modulechild.js');
console.log(module.children);
